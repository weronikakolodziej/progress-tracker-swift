<<<<<<< HEAD
This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.


## prompt 
**Prompt do AI (do wygenerowania aplikacji webowej z frontendem i backendem):**

> Stwórz responsywną aplikację webową zoptymalizowaną pod iPhone 14 Pro, która umożliwia użytkownikowi codzienne logowanie danych zdrowotnych, treningowych i żywieniowych oraz dostęp do własnych informacji. Strona startowa powinna zawierać **cztery kafelki / sekcje**:
>
> ### 1. **Dziennik**
> - Formularz dzienny, gdzie użytkownik loguje:
>   - Rodzaj aktywności fizycznej (checkboxy: trening siłowy, joga, padel, inne – z możliwością dodania własnych)
>   - Waga (kg)
>   - Liczba kroków
>   - Kalorie
>   - Ilość spożytego białka (g)
>   - Samopoczucie (skala 1–10)
>   - Jakość snu (skala 1–10)
>   - Komentarz tekstowy
>   - **Plan suplementacji** – lista suplementów (np. checkboxy lub liczba dawek dziennie)
>
> ### 2. **Treningi**
> - Ekran z **menu treningów siłowych** (np. push, pull, nogi)
> - Po kliknięciu w trening rozwija się szczegółowy widok:
>   - Lista ćwiczeń (każde z podaną liczbą serii i powtórzeń)
>   - Możliwość wpisywania: ile kg, ile serii/powtórzeń zrobiłam
>   - System automatycznie przypisuje datę logowania
>   - Możliwość podejrzenia historii logowania danego treningu z poziomu tego widoku
>
> ### 3. **Posiłki + Plan suplementacji**
> - Widok **kafelków z przepisami** (lista inspirujących posiłków)
> - Możliwość dodania nowego przepisu (nazwa, składniki, opis, zdjęcie)
>
> ### 4. **Informacje**
> - Lista własnych plików tekstowych – miejsce na **notatki, Plan suplementacji, zalecenia lekarskie, plan dnia, aktywności polecane przez lekarza** itd.
> - Możliwość dodawania, edytowania i usuwania takich notatek
>
> ### Dodatkowe funkcje:
> - **Ekran historii danych**:
>   - Jeden **ciągły, przewijany ekran** z widokiem wszystkich dni – zawierający dane dziennika z każdego dnia (aktywny styl timeline lub lista dat z podsumowaniem)
>   - Dodatkowo: wykresy (waga, kroki, kalorie, białko itp.)
>   - Dane treningowe z ostatniego miesiąca dostępne też przez ekran "Treningi"
>
> ### Technologia:
> - Frontend: React (lub Next.js), styled-components / Tailwind CSS, responsywny design pod iPhone 14 Pro
> - Backend: Firebase, Supabase lub Node.js + Express
> - Baza danych: Firestore / PostgreSQL
> - Logowanie: e-mail lub Google
> - Wykresy: Chart.js / Recharts
> - Możliwość rozszerzenia do PWA lub aplikacji mobilnej w przyszłości
> opcja deploy na vercel oraz aws + terraform + docker + k8s



### dane

=======
# progress-tracker
>>>>>>> origin/main
