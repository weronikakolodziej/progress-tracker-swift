import React from "react";

interface NumberInputProps {
  id: string;
  label: string;
  placeholder?: string;
  value: string | number;
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

const NumberInput: React.FC<NumberInputProps> = ({
  id,
  label,
  placeholder,
  value,
  onChange,
}) => {
  return (
    <div className="mb-5 ">
      <label
        htmlFor={id}
        className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
      >
        {label}
      </label>
      <input
        type="number"
        id={id}
        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
        placeholder={placeholder}
        value={value}
        onChange={onChange}
      />
    </div>
  );
};

interface FitnessInputsProps {
  weight: string;
  steps: string;
  calories: string;
  protein: string;
  onWeightChange: (value: string) => void;
  onStepsChange: (value: string) => void;
  onCaloriesChange: (value: string) => void;
  onProteinChange: (value: string) => void;
}

const FitnessInputs: React.FC<FitnessInputsProps> = ({
  weight,
  steps,
  calories,
  protein,
  onWeightChange,
  onStepsChange,
  onCaloriesChange,
  onProteinChange,
}) => {
  return (
    <>
      <NumberInput
        id="weight"
        label="Weight (kg)"
        placeholder="Weight"
        value={weight}
        onChange={(e) => onWeightChange(e.target.value)}
      />
      <NumberInput
        id="steps"
        label="Steps"
        placeholder="e.g., 10000"
        value={steps}
        onChange={(e) => onStepsChange(e.target.value)}
      />
      <NumberInput
        id="calories"
        label="Calories"
        placeholder="e.g., 2500"
        value={calories}
        onChange={(e) => onCaloriesChange(e.target.value)}
      />
      <NumberInput
        id="protein"
        label="Protein (g)"
        placeholder="e.g., 100"
        value={protein}
        onChange={(e) => onProteinChange(e.target.value)}
      />
    </>
  );
};

export default FitnessInputs;
