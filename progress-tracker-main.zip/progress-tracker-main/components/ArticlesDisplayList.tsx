"use client";

import React from 'react';
import Link from 'next/link';

interface DataItem {
  label: string;
  value: string;
  date?: string;
  id?: string; // Dodajemy opcjonalne ID artykułu
}

interface Props {
  data: DataItem[];
}

const ArticlesDisplayList: React.FC<Props> = ({ data }) => {
  return (
    <dl className="max-w-md text-gray-900 dark:text-white border-t border-gray-200 dark:border-gray-500">
      {data.map((item, index) => (
        <div
          key={index}
          className={`py-2 ${
            index > 0 ? 'border-t border-gray-200 dark:border-gray-700' : ''
          }`}
        >
          {item.id ? (
            <Link href={`/articles/${item.id}`} className="block hover:bg-gray-700 p-2 rounded-md">
              <dt className="mb-1 text-lg font-semibold text-white">{item.label}</dt>
              <div className="flex items-center justify-between">
                <dd className="text-gray-400 md:text-lg dark:text-gray-400">{item.value}</dd>
                {item.date && (
                  <dd className="text-sm text-gray-500 dark:text-gray-400">{item.date}</dd>
                )}
              </div>
            </Link>
          ) : (
            <>
              <dt className="mb-1 text-lg font-semibold text-white">{item.label}</dt>
              <div className="flex items-center justify-between">
                <dd className="text-gray-400 md:text-lg dark:text-gray-400">{item.value}</dd>
                {item.date && (
                  <dd className="text-sm text-gray-500 dark:text-gray-400">{item.date}</dd>
                )}
              </div>
            </>
          )}
        </div>
      ))}
    </dl>
  );
};

export default ArticlesDisplayList;