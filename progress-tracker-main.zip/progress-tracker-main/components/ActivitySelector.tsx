import React from 'react';

interface Activity {
  id: string;
  name: string;
  description: string;
}

interface ActivitySelectorProps {
  activities: Activity[];
  onChange?: (selectedIds: string[]) => void;
}

const ActivitySelector: React.FC<ActivitySelectorProps> = ({ activities, onChange }) => {
  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const checkbox = event.target;
    const value = checkbox.id;
    let selected: string[] = [];

    // Get all checked checkboxes within the same ul
    const checkedCheckboxes = Array.from(
      checkbox.closest('ul')?.querySelectorAll<HTMLInputElement>('input[type="checkbox"]:checked') || []
    );

    selected = checkedCheckboxes.map((input) => input.id);

    if (onChange) {
      onChange(selected);
    }
  };

  return (
    <>
      
      <ul className="grid w-full gap-3 grid-cols-3">
        {activities.map((activity) => (
          <li key={activity.id}>
            <input
              type="checkbox"
              id={activity.id + "-option"}
              value={activity.id}
              className="hidden peer"
              onChange={handleCheckboxChange}
            />
            <label
              htmlFor={activity.id + "-option"}
              className="inline-flex items-center justify-center  w-full p-2 text-gray-200 bg-white border-2 border-gray-200 rounded-2xl cursor-pointer dark:hover:text-gray-300 dark:border-gray-700 peer-checked:border-blue-600 dark:peer-checked:border-blue-600 hover:text-gray-600 dark:peer-checked:text-gray-300 peer-checked:text-gray-600 hover:bg-gray-50 dark:text-gray-400 dark:bg-gray-800 dark:hover:bg-gray-700"
            >
              <div className="block">
                <div className="w-full text-sm font-medium ">{activity.name}</div>
                
              </div>
            </label>
          </li>
        ))}
      </ul>
    </>
  );
};

export default ActivitySelector;