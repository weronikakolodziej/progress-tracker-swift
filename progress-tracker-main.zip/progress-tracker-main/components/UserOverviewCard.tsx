"use client";

import React, { useEffect, useState } from "react";
import { collection, query, orderBy, onSnapshot } from "firebase/firestore";
import { db, auth } from "@/lib/firebase";
import DataChartApex from "./DataChartApex";

interface FitnessEntry {
    weight?: number;
    calories?: number;
    protein?: number;
    steps?: number;
    createdAt:
    | { toDate: () => Date }
    | Date
    | { seconds: number; nanoseconds: number }
    | null;
}

interface UserOverviewCardProps {
    use?: "weight" | "calories" | "protein" | "steps";
    className?: string;
}

const UserOverviewCard: React.FC<UserOverviewCardProps> = ({ use = "weight", className }) => {
    const [fitnessData, setFitnessData] = useState<FitnessEntry[]>([]);
    const [userId, setUserId] = useState<string | null>(null);
    const [latestEntry, setLatestEntry] = useState<FitnessEntry | null>(null);
    const [averageCalories, setAverageCalories] = useState(0);
    const [averageSteps, setAverageSteps] = useState(0);
    const [averageProtein, setAverageProtein] = useState(0);

    useEffect(() => {
        const userId = auth.currentUser?.uid;

        if (!userId) {
            console.error("Użytkownik nie jest zalogowany.");
            setFitnessData([]);
            return () => {};
        }

        const userFitnessDataCollection = collection(
            db,
            "users",
            userId,
            "fitnessData"
        );
        const fitnessQuery = query(userFitnessDataCollection, orderBy("createdAt"));

        const unsubscribe = onSnapshot(
            fitnessQuery,
            (snapshot) => {
                const data: FitnessEntry[] = snapshot.docs.map((doc) => {
                    return doc.data() as FitnessEntry;
                });
                setFitnessData(data);
                setLatestEntry(data[data.length - 1] || null); // Najnowszy na końcu po sortowaniu rosnącym
            },
            (error) => {
                console.error("Błąd podczas pobierania danych fitness:", error);
            }
        );

        return () => unsubscribe();
    }, []);

    useEffect(() => {
        if (fitnessData.length > 0) {
            // Obliczanie średnich
            const totalCalories = fitnessData.reduce((sum, entry) => sum + (entry.calories || 0), 0);
            setAverageCalories(totalCalories / fitnessData.length || 0);

            const totalSteps = fitnessData.reduce((sum, entry) => sum + (entry.steps || 0), 0);
            setAverageSteps(totalSteps / fitnessData.length || 0);

            const totalProtein = fitnessData.reduce((sum, entry) => sum + (entry.protein || 0), 0);
            setAverageProtein(totalProtein / fitnessData.length || 0);
        }
    }, [fitnessData]);

    const prepareChartData = (data: FitnessEntry[], key: keyof Omit<FitnessEntry, "createdAt">) => {
        return data.map((entry) => ({
            date: entry.createdAt instanceof Date
                ? entry.createdAt
                : "toDate" in entry.createdAt
                    ? entry.createdAt.toDate()
                    : "seconds" in entry.createdAt
                        ? new Date(entry.createdAt.seconds * 1000)
                        : null,
            value: entry[key] !== undefined ? Number(entry[key]) : 0,
        }));
    };

    const metricLabels: Record<keyof Omit<FitnessEntry, 'createdAt'>, string> = {
        weight: "Waga",
        calories: "Kalorie",
        protein: "Białko",
        steps: "Kroki",
    };

    const currentMetricLabel = metricLabels[use] || metricLabels["weight"];
    const latestMetricValue = latestEntry ? latestEntry[use] : "0";
    const metricUnit: Record<keyof Omit<FitnessEntry, 'createdAt'>, string> = {
        weight: "kg",
        calories: "",
        protein: "g",
        steps: "",
    };
    const currentMetricUnit = metricUnit[use] || "";

    let progressText = "";
    let progressPercentage = 0;

    if (use === "weight" && fitnessData.length > 1 && latestEntry?.weight !== undefined && fitnessData[0]?.weight !== undefined) {
        const weightChange = latestEntry.weight - fitnessData[0].weight;
        progressText = `${weightChange > 0 ? "+" : ""}${weightChange.toFixed(1)} kg (od startu)`;
        // Możesz opcjonalnie obliczyć procentową zmianę wagi
    } else if (use === "calories" && latestEntry?.calories !== undefined) {
        const diff = latestEntry.calories - averageCalories;
        progressText = `${diff > 0 ? "+" : ""}${diff.toFixed(0)} (vs. średnia)`;
        progressPercentage = averageCalories === 0 ? 0 : Math.min(1, latestEntry.calories / averageCalories) * 100;
    } else if (use === "steps" && latestEntry?.steps !== undefined) {
        const diff = latestEntry.steps - averageSteps;
        progressText = `${diff > 0 ? "+" : ""}${diff.toFixed(0)} (vs. średnia)`;
        progressPercentage = averageSteps === 0 ? 0 : Math.min(1, latestEntry.steps / averageSteps) * 100;
    } else if (use === "protein" && latestEntry?.protein !== undefined) {
        const diff = latestEntry.protein - averageProtein;
        progressText = `${diff > 0 ? "+" : ""}${diff.toFixed(1)} g (vs. średnia)`;
        progressPercentage = averageProtein === 0 ? 0 : Math.min(1, latestEntry.protein / averageProtein) * 100;
    }

    return (
        <div className={`w-full dark:bg-gray-800 dark:border-gray-700 rounded-lg shadow-sm p-4 md:p- ${className || ""}`}>
            <div className="flex justify-between mb-4">
                <div>
                    <h5 className="leading-none text-3xl font-bold text-foreground dark:text-white">
                        {latestMetricValue} {currentMetricUnit}
                    </h5>
                    <p className="text-base font-normal text-secondary dark:text-gray-400">
                        {currentMetricLabel}
                    </p>
                </div>
                {progressText && (
                    <div className="text-sm font-medium text-secondary dark:text-gray-400">{progressText}</div>
                )}
            </div>

            {fitnessData.length > 0 ? (
                <div>
                    <DataChartApex
                        data={prepareChartData(fitnessData, use)}
                        name={currentMetricLabel}
                        color={metricColors[use] || "#1C64F2"}
                    />
                    {progressPercentage > 0 && use !== "weight" && (
                        <div className="mt-4">
                            <div className="relative pt-1">
                                <div className="overflow-hidden h-2 mb-2 text-xs flex rounded bg-gray-200 dark:bg-gray-700">
                                    <div
                                        style={{ width: `${progressPercentage}%` }}
                                        className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-${progressPercentage > 100 ? 'green' : 'blue'}-500 transition-all duration-500`}
                                    ></div>
                                </div>
                            </div>
                            <p className="text-sm text-secondary dark:text-gray-400">Średnia: {
                                use === "calories" ? averageCalories.toFixed(0) :
                                    use === "steps" ? averageSteps.toFixed(0) :
                                        use === "protein" ? averageProtein.toFixed(1) : ''
                            }</p>
                        </div>
                    )}
                </div>
            ) : (
                <p className="text-secondary dark:text-gray-400">Brak danych do wyświetlenia.</p>
            )}
        </div>
    );
};

const metricColors = { weight: "#1C64F2", calories: "#22C55E", protein: "#F59E0B", steps: "#EC4899" };

export default UserOverviewCard;