// app/components/GridMenu.tsx
"use client";

import React, { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";

interface Element {
  title: string;
  link: string;
  imageSrc?: string;
  description?: string;
}

const defaultElements: Element[] = [
  {
    title: "Log the data",
    link: "/addData",
    imageSrc:
      "https://img.freepik.com/premium-photo/focused-female-data-analyst-examining-comprehensive-financial-graphs-large-monitor-modern-office_1199903-57539.jpg?w=2000",
    description: "Record and analyze your data.",
  },
  {
    title: "Workouts",
    link: "/workouts",
    imageSrc:
      "https://img.freepik.com/free-photo/portrait-anime-character-doing-fitness-exercising_23-2151666669.jpg?t=st=1746714000~exp=1746717600~hmac=59cf99aac27a5c359c6b078c16ad3079756d93e6c7c60e427177f2d913613e15&w=900",
    description: "Track your training sessions.",
  },
  {
    title: "Meals",
    link: "/meals",
    imageSrc:
      "https://img.freepik.com/free-vector/illustration-chuseok-festival-celebration_52683-135079.jpg?t=st=1746713890~exp=1746717490~hmac=08d8c6bcb1298f4ac0848cc07ec802d7e1d4510cbbde37c4076be8f4872526f7&w=1380",
    description: "Your favorite meal recipes.",
  },
  {
    title: "Knowledge",
    link: "/articles",
    imageSrc:
      "https://img.freepik.com/premium-vector/anime-scene-background-library-home-vector-art-illustration-studio-ghibli-makoto-shinkai-style_1001131-234.jpg?w=2000",
    description: "Browse useful articles.",
  },
];

const mealsData: Element[] = [
  {
    title: "Breakfast",
    link: "/meals/breakfast",
    imageSrc:
      "https://img.freepik.com/free-photo/healthy-breakfast-table-with-croissants-fruits_114579-5598.jpg?w=900",
    description: "Start your day with a nutritious meal.",
  },
  {
    title: "Lunch",
    link: "/meals/lunch",
    imageSrc:
      "https://img.freepik.com/free-photo/top-view-bowl-with-rice-vegetables-chopsticks_23-2148673423.jpg?w=900",
    description: "Midday nourishment to keep you going.",
  },
  {
    title: "Dinner",
    link: "/meals/dinner",
    imageSrc:
      "https://img.freepik.com/free-photo/grilled-salmon-with-vegetables-herbs_141793-1431.jpg?w=900",
    description: "A satisfying end to your day.",
  },
  {
    title: "Snacks",
    link: "/meals/snacks",
    imageSrc:
      "https://img.freepik.com/free-photo/nuts-dried-fruits-wooden-bowl_114579-1030.jpg?w=900",
    description: "Healthy bites between main meals.",
  },
];

interface GridMenuProps {
  use?: "elements" | "meals";
  className?: string; // Add the className prop to the interface
}

export const GridMenu: React.FC<GridMenuProps> = ({ use, className }) => {
  const pathname = usePathname();
  const [currentPath, setCurrentPath] = useState<string | null>(null);
  const [isRouterReady, setIsRouterReady] = useState(false);

  useEffect(() => {
    setIsRouterReady(true);
    setCurrentPath(pathname);
    console.log("GridMenu currentPath:", pathname);
  }, [pathname]);

  if (!isRouterReady && !use) {
    return <div>...</div>;
  }

  let dataToUse: Element[] = defaultElements;

  if (use === "meals" || currentPath === "/meals") {
    dataToUse = mealsData;
  } else if (use === "elements") {
    dataToUse = defaultElements;
  }

  return (
    <div className={`grid grid-cols-2 gap-6 ${className}`}>
      {" "}
      {/* Apply the className */}
      {dataToUse.map((item) => (
        <div
          key={item.link}
          className="bg-white border border-gray-200 rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700 overflow-hidden flex flex-col"
        >
          {item.imageSrc && (
            <a href={item.link} className="block overflow-hidden">
              <div className="relative aspect-[4/3] w-full flex-grow">
                <img
                  className="w-full h-full object-cover"
                  src={item.imageSrc}
                  alt={item.title}
                />
              </div>
            </a>
          )}
          <div className="p-5 flex flex-col justify-center">
            <a href={item.link}>
              <h5 className="mb-1 text-l font-bold tracking-tight text-gray-900 dark:text-white">
                {item.title}
              </h5>
            </a>
            {item.description && (
              <p className="mb-1 font-normal text-gray-700 dark:text-gray-400 text-sm">
                {item.description}
              </p>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};
