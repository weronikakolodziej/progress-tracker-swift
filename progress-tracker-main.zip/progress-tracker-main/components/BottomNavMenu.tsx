import Link from "next/link";
import React from "react";

interface NavItem {
  id: string;
  icon: React.ReactNode;
  label: string;
  tooltip: string;
  href: string;
  position?: "left" | "center" | "right";
}

interface BottomNavMenuProps {}

const BottomNavMenu: React.FC<BottomNavMenuProps> = () => {
  const navigationItems: NavItem[] = [
    {
      id: "bookmark",
      icon: (
        <svg
          className="w-5 h-5 mb-1 text-gray-500 dark:text-gray-400 group-hover:text-blue-600 dark:group-hover:text-blue-500"
          aria-hidden="true"
          xmlns="http://www.w3.org/2000/svg"
          fill="currentColor"
          viewBox="0 0 14 20"
        >
          <path d="M13 20a1 1 0 0 1-.64-.231L7 15.3l-5.36 4.469A1 1 0 0 1 0 19V2a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v17a1 1 0 0 1-1 1Z" />
        </svg>
      ),
      label: "Bookmark",
      tooltip: "Bookmark",
      href: "/addArticle",
      position: "left",
    },
    {
      id: "home",
      icon: (
        <svg
          className="w-5 h-5 mb-1 text-gray-500 dark:text-gray-400 group-hover:text-blue-600 dark:group-hover:text-blue-500"
          aria-hidden="true"
          xmlns="http://www.w3.org/2000/svg"
          fill="currentColor"
          viewBox="0 0 20 20"
        >
          <path d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
        </svg>
      ),
      label: "Home",
      tooltip: "Home",
      href: "/",
      position: "center",
    },
    {
      id: "me",
      icon: (
        <svg
          className="w-5 h-5 mb-1 text-gray-500 dark:text-gray-400 group-hover:text-blue-600 dark:group-hover:text-blue-500"
          aria-hidden="true"
          xmlns="http://www.w3.org/2000/svg"
          fill="currentColor"
          viewBox="0 0 20 20"
        >
          <path d="M10 0a10 10 0 1 0 10 10A10.011 10.011 0 0 0 10 0Zm0 5a3 3 0 1 1 0 6 3 3 0 0 1 0-6Zm0 13a8.949 8.949 0 0 1-4.951-1.488A3.987 3.987 0 0 1 9 13h2a3.987 3.987 0 0 1 3.951 3.512A8.949 8.949 0 0 1 10 18Z" />
        </svg>
      ),
      label: "Me",
      tooltip: "My Profile",
      href: "/profile",
      position: "right",
    },
  ];

  return (
    <div className="fixed bottom-0 z-50 w-full -translate-x-1/2 bg-black border-t border-gray-700 left-1/2">
      <div className="h-full max-w-lg mx-auto flex justify-around items-center">
        {navigationItems.map((item) => (
          <div
            key={item.id}
            className="flex flex-col items-center justify-center p-4"
          >
            <Link href={item.href} aria-label={item.label}>
              <button
                data-tooltip-target={`tooltip-${item.id}`}
                type="button"
                className="group"
              >
                {item.icon}
                <span className="sr-only">{item.label}</span>
              </button>
            </Link>
            <div
              id={`tooltip-${item.id}`}
              role="tooltip"
              className="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-xs opacity-0 tooltip dark:bg-gray-700"
            >
              {item.tooltip}
              <div className="tooltip-arrow" data-popper-arrow></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BottomNavMenu;
