"use client";

import React from "react";
import dynamic from "next/dynamic";
import { format } from "date-fns";

const ReactApexChart = dynamic(() => import("react-apexcharts"), {
  ssr: false,
});

interface DataPoint {
  date: Date | { toDate: () => Date } | { seconds: number; nanoseconds: number } | null;
  value: number;
}

interface DataChartApexProps {
  data: DataPoint[];
  name: string;
  color?: string;
}

const DataChartApex: React.FC<DataChartApexProps> = ({ data, name, color = "#1C64F2" }) => {
  const series = [
    {
      name: name,
      data: data.map((item) => ({
        x: item.date
          ? item.date instanceof Date
            ? item.date
            : 'toDate' in item.date
            ? item.date.toDate()
            : 'seconds' in item.date
            ? new Date(item.date.seconds * 1000)
            : new Date(0) // Fallback for invalid date
          : new Date(0),
        y: item.value,
      })),
    },
  ];

  const options = {
    chart: {
      height: "100%",
      maxWidth: "100%",
      type: "area",
      fontFamily: "Inter, sans-serif",
      dropShadow: {
        enabled: false,
      },
      toolbar: {
        show: false,
      },
    },
    tooltip: {
      enabled: true,
      x: {
        format: "dd/MM/yyyy",
      },
    },
    fill: {
      type: "gradient",
      gradient: {
        opacityFrom: 0.55,
        opacityTo: 0,
        shade: color,
        gradientToColors: [color],
      },
    },
    dataLabels: {
      enabled: false,
    },
    stroke: {
      width: 3,
      curve: 'smooth',
    },
    grid: {
      show: false,
      strokeDashArray: 4,
      padding: {
        left: 2,
        right: 2,
        top: 0,
      },
    },
    xaxis: {
      type: 'datetime',
      labels: {
        show: true,
      },
      axisBorder: {
        show: false,
      },
      axisTicks: {
        show: false,
      },
    },
    yaxis: {
      show: false,
    },
    colors: [color],
  };

  return (
    <div className="h-40">
      <ReactApexChart options={options} series={series} type="area" height="100%" />
    </div>
  );
};

export default DataChartApex;