"use client";

import React, { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";

const MyHeader: React.FC = () => {
  const pathname = usePathname();
  const [isHomePage, setIsHomePage] = useState(false);
  const [isRouterReady, setIsRouterReady] = useState(false);

  useEffect(() => {
    setIsRouterReady(true);
    setIsHomePage(pathname === "/");
    console.log("Current path:", pathname);
  }, [pathname]);

  if (!isRouterReady) {
    return (
      <nav className="bg-black border-b border-gray-700 fixed w-full z-20 top-0 start-0">
        <div className="max-w-screen-xl flex items-center justify-center mx-auto p-3">
          <Link href="/" className="flex items-center">
            <Image
              src="https://img.freepik.com/premium-vector/dog-vector-mascot-logo-inspiration_706080-166.jpg?w=1480"
              height={32}
              width={32}
              alt="Logo"
            />
          </Link>
        </div>
      </nav>
    );
  }

  return (
    <nav className="bg-black border-b border-gray-700 fixed w-full z-20 top-0 start-0">
      <div className="max-w-screen-xl flex items-center justify-between mx-auto p-2">
        <div className="w-1/3 flex justify-start">
          {!isHomePage && (
            <Link
              href="/"
              className="text-gray-400 hover:underline flex items-center px-4"
            >
              &lt;
            </Link>
          )}
        </div>
        <div className="flex justify-center w-1/3">
          <Link href="/" className="flex items-center">
            <Image
              src="https://img.freepik.com/premium-vector/dog-vector-mascot-logo-inspiration_706080-166.jpg?w=1480"
              height={32}
              width={32}
              alt="Logo"
            />
          </Link>
        </div>
        <div className="w-1/3 flex justify-end">
          {/* Możesz tutaj dodać inne elementy po prawej stronie */}
        </div>
      </div>
    </nav>
  );
};

export default MyHeader;
