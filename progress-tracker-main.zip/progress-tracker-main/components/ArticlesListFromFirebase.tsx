"use client";

import React, { useState, useEffect } from "react";
import { db, auth } from "@/lib/firebase";
import { collection, query, orderBy, onSnapshot } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import ArticlesDisplayList from "@/components/ArticlesDisplayList"; // Upewnij się, że ścieżka jest poprawna

interface Article {
  id: string;
  title: string;
  content: string;
  createdAt: { toDate: () => Date } | null;
}

const ArticlesListFromFirebase: React.FC = () => {
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUserId(user.uid);
      } else {
        setUserId(null);
        setArticles([]);
        setLoading(false);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  useEffect(() => {
    if (userId) {
      const articlesCollectionRef = collection(db, "users", userId, "articles");
      const q = query(articlesCollectionRef, orderBy("createdAt", "desc"));

      const unsubscribeFirestore = onSnapshot(
        q,
        (snapshot) => {
          const fetchedArticles = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...(doc.data() as Omit<Article, "id">),
          }));
          setArticles(fetchedArticles);
          setLoading(false);
        },
        (err) => {
          console.error("Błąd podczas pobierania artykułów:", err);
          setError("Nie udało się pobrać artykułów.");
          setLoading(false);
        }
      );

      return () => unsubscribeFirestore();
    }
  }, [userId]);

  if (loading) {
    return (
      <div className="bg-gray-800 min-h-screen p-6">
        <p>...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-gray-800 min-h-screen p-6">
        <p>Error: {error}</p>
      </div>
    );
  }

  const dataForList = articles.map((article) => ({
    id: article.id, // Przekazujemy ID
    label: article.title,
    value:
      article.content.substring(0, 100) +
      (article.content.length > 100 ? "..." : ""),
    date: article.createdAt?.toDate().toLocaleDateString(),
  }));

  return (
    <div className="rounded-lg bg-gray-800 min-h-screen p-6">
      {dataForList.length > 0 ? (
        <ArticlesDisplayList data={dataForList} />
      ) : (
        <p>Add something </p>
      )}
    </div>
  );
};

export default ArticlesListFromFirebase;