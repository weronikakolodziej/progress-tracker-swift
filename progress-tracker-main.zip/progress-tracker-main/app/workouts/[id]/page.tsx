"use client";

import { useEffect, useState } from "react";
import {
  doc,
  getDoc,
  collection,
  addDoc,
  serverTimestamp,
  query,
  where,
  orderBy,
  getDocs as getFirestoreDocs,
} from "firebase/firestore";
import { db, auth } from "@/lib/firebase";
import { useRouter, useParams } from "next/navigation";
import MyHeader from "@/components/MyHeader";
import BottomNavMenu from "@/components/BottomNavMenu";
import dynamic from "next/dynamic";

// Dynamicznie zaimportuj komponenty ApexCharts, aby uniknąć problemów po stronie serwera
const DataChartApex = dynamic(() => import("@/components/DataChartApex"), {
  ssr: false,
});
// Zakładam, że masz ten komponent w tej ścieżce
// const UserOverviewCard = dynamic(() => import('@/components/UserOverviewCard'), { ssr: false });

type Workout = {
  id: string;
  category: string;
  name: string;
  exercises: {
    exerciseName: string;
    rest?: string;
    series: number;
    reps: number | string;
    weights?: number | string;
    alternativeExercise?: string;
    link?: string;
  }[];
};

type LoggedSet = {
  reps: number | null;
  weight: number | null;
};

type ExerciseLogs = {
  exerciseName: string;
  sets: LoggedSet[];
};

type HistoricalLog = {
  reps: number | null;
  weight: number | null;
  date: Date;
};

export default function WorkoutDetails() {
  const router = useRouter();
  const params = useParams();
  const { id } = params;
  const [workout, setWorkout] = useState<Workout | null>(null);
  const [exerciseLogs, setExerciseLogs] = useState<ExerciseLogs[]>([]);
  const [user, setUser] = useState(auth.currentUser);
  const [historicalData, setHistoricalData] = useState<
    Record<string, HistoricalLog[]>
  >({});

  useEffect(() => {
    const unsubscribeAuth = auth.onAuthStateChanged((currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribeAuth();
  }, []);

  useEffect(() => {
    async function fetchWorkout() {
      if (id && user?.uid) {
        const docRef = doc(db, "users", user.uid, "workouts", id as string);
        const snapshot = await getDoc(docRef);
        if (snapshot.exists()) {
          const workoutData = snapshot.data() as Omit<Workout, "id"> & {
            exercises: string;
          };
          let exercisesArray;
          try {
            exercisesArray = JSON.parse(workoutData.exercises);
          } catch (e) {
            console.error("Błąd parsowania JSON dla exercises:", e);
            exercisesArray = [];
          }
          setWorkout({
            id: snapshot.id,
            ...workoutData,
            exercises: exercisesArray,
          } as Workout);
        } else {
          console.log("Nie znaleziono treningu!");
          setWorkout(null);
        }
      }
    }

    if (id && user?.uid) {
      fetchWorkout();
    }
  }, [id, user?.uid]);

  useEffect(() => {
    if (workout?.exercises) {
      const initialLogs: ExerciseLogs[] = workout.exercises.map((exercise) => ({
        exerciseName: exercise.exerciseName,
        sets: Array(exercise.series).fill({ reps: null, weight: null }),
      }));
      setExerciseLogs(initialLogs);
    }
  }, [workout?.exercises]);

  useEffect(() => {
    async function fetchHistoricalLogs() {
      if (user?.uid && workout?.exercises) {
        const historicalDataMap: Record<string, HistoricalLog[]> = {};
        const exerciseLogsCollection = collection(
          db,
          "users",
          user.uid,
          "exerciseLogs"
        );

        for (const exercise of workout.exercises) {
          const q = query(
            exerciseLogsCollection,
            where("workoutId", "==", workout.id),
            where("exerciseName", "==", exercise.exerciseName),
            orderBy("date", "asc") // Sortuj daty rosnąco dla wykresu
          );
          const snapshot = await getFirestoreDocs(q);
          const logs: HistoricalLog[] = snapshot.docs.map((doc) => {
            const data = doc.data();
            return {
              reps: data.reps,
              weight: data.weight,
              date: (data.date as { toDate: () => Date })?.toDate(),
            };
          });
          historicalDataMap[exercise.exerciseName] = logs;
        }
        setHistoricalData(historicalDataMap);
      }
    }

    if (workout) {
      fetchHistoricalLogs();
    }
  }, [user?.uid, workout]);

  const handleLogChange = (
    exerciseIndex: number,
    setIndex: number,
    field: keyof LoggedSet,
    value: string
  ) => {
    const newExerciseLogs = [...exerciseLogs];
    const newValue = value === "" ? null : parseInt(value);
    newExerciseLogs[exerciseIndex].sets[setIndex] = {
      ...newExerciseLogs[exerciseIndex].sets[setIndex],
      [field]: newValue,
    };
    setExerciseLogs(newExerciseLogs);
  };

  const handleSubmitLog = async () => {
    if (!workout || !user) {
      console.error("Nie zalogowano użytkownika lub brak treningu.");
      return;
    }

    const userExerciseLogsCollection = collection(
      db,
      "users",
      user.uid,
      "exerciseLogs"
    );

    for (const exerciseLog of exerciseLogs) {
      for (const set of exerciseLog.sets) {
        if (set.reps !== null || set.weight !== null) {
          await addDoc(userExerciseLogsCollection, {
            workoutId: workout.id,
            exerciseName: exerciseLog.exerciseName,
            reps: set.reps,
            weight: set.weight,
            date: serverTimestamp(),
          });
        }
      }
    }

    alert("Zalogowano trening!");
    router.push("/");
  };

  if (!workout) {
    return (
      <div className="min-h-screen mx-auto pt-16 px-6 p-6">
        <MyHeader />
        <p>Loading...</p>
        <BottomNavMenu />
      </div>
    );
  }

  return (
    <div className="min-h-screen mx-auto pt-16 pb-18 px-6 p-6">
      <MyHeader />
      <h1 className="text-2xl font-bold mb-4">{workout.name}</h1>
      <br></br>
      <ul>
        {workout.exercises.map((exercise, index) => (
          <li key={index} className="mb-6">
            <h3 className="text-xl font-semibold">
              {index + 1}. {exercise.exerciseName}:{" "}
            </h3>
            <h3 className="text-l mb-4">
              {exercise.series}
              {exercise.reps && ` × ${exercise.reps} reps`}
              {exercise.weights && `, ${exercise.weights} kg`}
            </h3>
            <div className="grid grid-cols-2 gap-4 mb-2">
              <div>
                {Array(exercise.series)
                  .fill(null)
                  .map((_, setIndex) => (
                    <div key={setIndex} className="mb-2">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label
                            htmlFor={`weight-${index}-${setIndex}`}
                            className="block text-sm font-medium text-gray-700 dark:text-gray-300"
                          >
                            kg:
                          </label>
                          <input
                            type="number"
                            id={`weight-${index}-${setIndex}`}
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-300"
                            value={
                              exerciseLogs[index]?.sets[setIndex]?.weight ?? ""
                            }
                            onChange={(e) =>
                              handleLogChange(
                                index,
                                setIndex,
                                "weight",
                                e.target.value
                              )
                            }
                          />
                        </div>
                        <div>
                          <label
                            htmlFor={`reps-${index}-${setIndex}`}
                            className="block text-sm font-medium text-gray-700 dark:text-gray-300"
                          >
                            reps:
                          </label>
                          <input
                            type="number"
                            id={`reps-${index}-${setIndex}`}
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-300"
                            value={
                              exerciseLogs[index]?.sets[setIndex]?.reps ?? ""
                            }
                            onChange={(e) =>
                              handleLogChange(
                                index,
                                setIndex,
                                "reps",
                                e.target.value
                              )
                            }
                          />
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
              <div className="pt-6 align-self-center">
                {historicalData[exercise.exerciseName] &&
                historicalData[exercise.exerciseName].length > 1 ? (
                  <DataChartApex
                    series={[
                      {
                        name: "Waga (kg)",
                        data: historicalData[exercise.exerciseName].map(
                          (log) => [
                            new Date(log.date).getTime(), // ApexCharts oczekuje timestampów
                            log.weight ?? 0,
                          ]
                        ),
                      },
                    ]}
                    options={{
                      chart: {
                        type: "line",
                        height: 350, // Możesz dostosować wysokość
                        zoom: {
                          enabled: false,
                        },
                      },
                      dataLabels: {
                        enabled: false,
                      },
                      stroke: {
                        curve: "smooth",
                      },
                      markers: {
                        size: 0,
                      },
                      xaxis: {
                        type: "datetime",
                        labels: {
                          format: "dd MMM yy",
                        },
                        title: {
                          text: "Data",
                        },
                      },
                      yaxis: {
                        title: {
                          text: "Waga (kg)",
                        },
                        min: 0, // Możesz ustawić dynamiczne minimum
                      },
                      tooltip: {
                        x: {
                          format: "dd MMM yyyy HH:mm",
                        },
                      },
                      title: {
                        text: `Progress: ${exercise.exerciseName}`,
                        align: "left",
                      },
                    }}
                  />
                ) : (
                  <p className="text-xs text-gray-500 dark:text-gray-500">
                    No weight history available for this exercise. Log your
                    workouts to see progress!
                  </p>
                )}
              </div>
            </div>
          </li>
        ))}
      </ul>

      <button
        onClick={handleSubmitLog}
        className="px-4 py-2 rounded bg-blue-600 text-white mt-6"
      >
        Save
      </button>
      <BottomNavMenu />
    </div>
  );
}
