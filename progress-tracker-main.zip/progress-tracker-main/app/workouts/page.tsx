"use client";
import { useEffect, useState } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db, auth } from "@/lib/firebase";
import Link from "next/link";
import MyHeader from "@/components/MyHeader";
import BottomNavMenu from "@/components/BottomNavMenu";

type Workout = {
  id: string;
  category: string;
  name: string;
  exercises: {
    exerciseName: string;
    rest?: string;
    series: number;
    reps: number;
    weights?: number;
    alternativeExercise?: string;
    link?: string;
  }[];
};

export default function Treningi() {
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const user = auth.currentUser;

  useEffect(() => {
    const unsubscribeAuth = auth.onAuthStateChanged((user) => {
      if (user) {
        async function fetchUserWorkouts() {
          const userWorkoutsCollection = collection(
            db,
            "users",
            user.uid,
            "workouts"
          );
          const snapshot = await getDocs(userWorkoutsCollection);
          const data: Workout[] = [];
          const cats = new Set<string>();
          snapshot.forEach((doc) => {
            const workoutData = doc.data() as Omit<Workout, "id"> & {
              exercises: string;
            }; // Założenie, że exercises jest stringiem
            let exercisesArray;
            try {
              exercisesArray = JSON.parse(workoutData.exercises);
            } catch (e) {
              console.error("Błąd parsowania JSON dla exercises:", e);
              exercisesArray = []; // W przypadku błędu ustaw pustą tablicę
            }
            data.push({
              id: doc.id,
              ...workoutData,
              exercises: exercisesArray,
            });
            if (workoutData.category) cats.add(workoutData.category);
          });
          setWorkouts(data);
          setCategories(Array.from(cats).sort()); // Sortowanie kategorii alfabetycznie
        }
        fetchUserWorkouts();
      } else {
        setWorkouts([]);
        setCategories([]);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  const filteredWorkouts = selectedCategory
    ? workouts.filter((w) => w.category === selectedCategory)
    : workouts;

  if (!user) {
    return (
      <div className="min-h-screen mx-auto pt-16 px-6 p-6">
        <MyHeader />
        <p>Logging...</p>
        <BottomNavMenu />
      </div>
    );
  }

  return (
    <div className=" min-h-screen  mx-auto pt-16 br-16 px-6 p-6">
      <MyHeader />
      <h1 className="text-2xl font-bold mb-4">My workouts</h1>

      <div className=" w-full grid-cols-3 rounded-lg inline-flex items-center justify-center p-2 gap-4 mb-4">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded ${
              selectedCategory === cat
                ? "bg-gray-700 text-white"
                : "bg-gray-900"
            }`}
          >
            {cat}
          </button>
        ))}
        {/* {selectedCategory && (
          <button
            onClick={() => setSelectedCategory(null)}
            className="px-4 py-2 rounded bg-red-400 text-white"
          >
            Wyczyść filtr
          </button>
        )} */}
      </div>
      
      <ul>
        {filteredWorkouts.map((w) => (
          <li key={w.id} className="mb-3 bg-gray-900 p-4 p-7rounded shadow">
            <h3 className="font-semibold">
              <Link
                href={`/workouts/${w.id}`}
                className="text-xl font-semibold pb-4"
              >
                {w.name}
              </Link>
            </h3>
            <ul className="ml-4 pt-3 list-disc">
              {w.exercises.map((el, i) => (
                <li key={i}>
                  {el.exerciseName}
                  {el.link && ` (link)`}
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    
      <BottomNavMenu />
    </div>
  );
}