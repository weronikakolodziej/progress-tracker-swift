"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import MyHeader from "../../components/MyHeader";
import { db, auth } from "@/lib/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import { useRouter } from "next/navigation";
import BottomNavMenu from "@/components/BottomNavMenu";

interface User {
  uid: string | null;
}

const KnowledgeArticleForm: React.FC = () => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [user, setUser] = useState<User>({ uid: null });
  const router = useRouter();
  const contentTextAreaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser({ uid: currentUser?.uid || null });
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (contentTextAreaRef.current) {
      contentTextAreaRef.current.style.height = "auto";
      contentTextAreaRef.current.style.height =
        contentTextAreaRef.current.scrollHeight + "px";
    }
  }, [content]);

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value);
  };

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    if (contentTextAreaRef.current) {
      contentTextAreaRef.current.style.height = "auto";
      contentTextAreaRef.current.style.height =
        contentTextAreaRef.current.scrollHeight + "px";
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImage(e.target.files[0]);
    }
  };

  const handleSave = async () => {
    if (!user.uid) {
      alert("Musisz być zalogowany, aby dodać artykuł.");
      return;
    }

    try {
      const articlesCollectionRef = collection(
        db,
        "users",
        user.uid,
        "articles"
      );
      await addDoc(articlesCollectionRef, {
        title,
        content,
        createdAt: serverTimestamp(),
      });
      alert("Artykuł został zapisany!");
      setTitle("");
      setContent("");
      setImage(null);
      router.push("/articles");
    } catch (error: any) {
      console.error("Błąd podczas zapisywania artykułu:", error);
      alert("Wystąpił błąd podczas zapisywania artykułu.");
    }
  };

  return (
    <div className="relative min-h-screen max-w-3xl mx-auto p-6 pb-16 flex flex-col bg-black text-gray-400">
      <MyHeader />
      <br />
      <br />
      <br />
      <h1 className="text-2xl font-bold mb-4 text-gray-400">Add Article</h1>

      <div className="mb-5 mt-2 relative">
        <input
          type="text"
          id="title"
          className="block py-2.5 px-0 w-full text-sm text-gray-900 dark:text-white bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer"
          placeholder="title "
          value={title}
          onChange={handleTitleChange}
          required
        />
        <label
          htmlFor="title"
          className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-white peer-focus:dark:text-white peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:-translate-y-6"
        >
          Tytuł Artykułu
        </label>
      </div>

      <div className="mb-5 mt-2 relative">
        <textarea
          ref={contentTextAreaRef}
          id="content"
          className="block py-2.5 px-0 flex-grow w-full text-sm text-gray-900 dark:text-white bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer resize-none"
          placeholder="type here "
          value={content}
          onChange={handleContentChange}
          style={{ overflowY: "hidden" }}
          rows={10}
          required
        />
        <label
          htmlFor="content"
          className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-white peer-focus:dark:text-white peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:-translate-y-6"
        >
          Article:
        </label>
      </div>

      <div className="mb-4">
        <label htmlFor="image" className="block text-sm  font-medium mb-2">
          Attach files (optional):
        </label>
        <input
          type="file"
          id="image"
          className="shadow-sm  text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          onChange={handleImageChange}
          accept="image/*"
        />
      </div>

      <button
        onClick={handleSave}
        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
      >
        Save
      </button>
      <BottomNavMenu />
    </div>
  );
};

export default KnowledgeArticleForm;
