"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { auth, User } from "@/lib/firebase"; // Import User type
import { onAuthStateChanged, signOut } from "firebase/auth";
import { useRouter } from "next/navigation";
import MyHeader from "../../components/MyHeader";
import ArticlesListFromFirebase from "@/components/ArticlesListFromFirebase";
import BottomNavMenu from "@/components/BottomNavMenu";

export default function HomePage() {
  const [user, setUser] = useState<User | null>(null); // Explicitly type the user state
  const router = useRouter();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (!u) router.push("/auth/login");
    });
    return () => unsubscribe();
  }, [router]);

  if (!user) {
    return <p className="text-center mt-10">Loading...</p>;
  }

  return (
    <div className="relative min-h-screen max-w-3xl mx-auto p-4 pt-16 pb-16 flex flex-col">
      <div>
        <MyHeader></MyHeader>
      </div>
      <div className="mt-8" />
      <ArticlesListFromFirebase />
      <BottomNavMenu />
    </div>
  );
}
