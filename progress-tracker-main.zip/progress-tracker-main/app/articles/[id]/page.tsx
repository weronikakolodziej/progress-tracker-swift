"use client";

import React, { useState, useEffect } from "react";
import { db, auth } from "@/lib/firebase";
import { doc, getDoc } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import { useParams } from "next/navigation";
import BottomNavMenu from "@/components/BottomNavMenu";
import MyHeader from "@/components/MyHeader";

interface Article {
  title: string;
  content: string;
  imageUrls?: string[];
}

const ArticleView: React.FC = () => {
  const [article, setArticle] = useState<Article | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const { id } = useParams();

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      setUserId(user?.uid || null);
    });
    return () => unsubscribeAuth();
  }, []);

  useEffect(() => {
    if (userId && id) {
      const articleDocRef = doc(db, "users", userId, "articles", id as string);
      getDoc(articleDocRef)
        .then((docSnap) => {
          if (docSnap.exists()) {
            setArticle(docSnap.data() as Article);
          } else {
            setError("Artykuł nie znaleziony.");
          }
          setLoading(false);
        })
        .catch((err) => {
          console.error("Błąd podczas pobierania artykułu:", err);
          setError("Nie udało się pobrać artykułu.");
          setLoading(false);
        });
    }
  }, [userId, id]);

  if (loading) {
    return <div className="p-6 text-white">Loading...</div>;
  }

  if (error) {
    return <div className="p-6 text-red-500">Error:: {error}</div>;
  }

  if (!article) {
    return <div className="p-6 text-white">No such article!</div>;
  }

  return (
    
    <div className="p-6 text-whit mb-16"><div><MyHeader /></div>
      <h1 className="text-2xl font-bold mt-16 mb-4">{article.title}</h1>
      <div className="mb-4">{article.content}</div>
      {article.imageUrls && article.imageUrls.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold mb-2">Attachments:</h2>
          <div className="flex flex-wrap gap-4">
            {article.imageUrls.map((url, index) => (
              <img key={index} src={url} alt={`Załącznik ${index + 1}`} className="max-w-full h-auto rounded-md" />
            ))}
          </div>
        </div>
      )}
      <BottomNavMenu />
    </div>
    
  );
};

export default ArticleView;