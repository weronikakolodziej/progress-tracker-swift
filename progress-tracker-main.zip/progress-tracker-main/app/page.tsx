"use client";
import { Metadata } from "next";
import Link from "next/link";
import { useEffect, useState } from "react";
import { auth, User } from "@/lib/firebase"; // Import User type
import { onAuthStateChanged, signOut } from "firebase/auth";
import { useRouter } from "next/navigation";
import { GridMenu } from "../components/GridMenu";
import MyHeader from "../components/MyHeader";
import UserOverviewCard from "../components/UserOverviewCard";
import BottomNavMenu from "@/components/BottomNavMenu";

export default function HomePage() {
  const [user, setUser] = useState<User | null>(null); // Explicitly type the user state
  const router = useRouter();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (!u) router.push("/auth/login");
    });
    return () => unsubscribe();
  }, [router]);

  if (!user) {
    return <p className="text-center mt-10">Loading...</p>;
  }

  const handleLogout = async () => {
    await signOut(auth);
    router.push("/auth/login");
  };

  return (
    <div className="relative min-h-screen max-w-3xl mx-auto p-6 pt-16 pb-16 flex flex-col">
      <div>
        <MyHeader />
      </div>
      <div className="mt-3" />
      <h1 className="text-3xl font-bold mb-6">
        Hello,<br></br> {user.displayName}
      </h1>
      <div className="mt-4 w-full">
        <UserOverviewCard />
      </div>
      <div className="mt-8 w-full">
        <GridMenu />
      </div>
      <BottomNavMenu />
    </div>
  );
}
