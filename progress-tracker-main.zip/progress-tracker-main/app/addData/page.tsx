"use client";

import { useState, useEffect, useRef } from "react";
import { db, auth } from "@/lib/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import { useRouter } from "next/navigation"; // Import useRouter
import MyHeader from "../../components/MyHeader";
import ActivitySelector from "../../components/ActivitySelector";
import FitnessInputs from "../../components/FitnessInputs";

const initialActivities = ["Gym", "Yoga", "Padel"];

interface SupplementsState {
  [key: string]: number;
}

export default function FitnessDiary() {
  const [user, setUser] = useState<any>(null);
  const [selectedActivities, setSelectedActivities] = useState<string[]>([]);
  const [customActivity, setCustomActivity] = useState("");
  const [weight, setWeight] = useState("");
  const [steps, setSteps] = useState("");
  const [calories, setCalories] = useState("");
  const [protein, setProtein] = useState("");
  const [mood, setMood] = useState(5);
  const [sleepQuality, setSleepQuality] = useState(5);
  const [notes, setNotes] = useState("");
  const [supplements, setSupplements] = useState<SupplementsState>({});
  const notesTextAreaRef = useRef<HTMLTextAreaElement>(null);
  const router = useRouter(); // Initialize useRouter

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => setUser(u));
    return () => unsub();
  }, []);

  useEffect(() => {
    if (notesTextAreaRef.current) {
      notesTextAreaRef.current.style.height = "auto";
      notesTextAreaRef.current.style.height =
        notesTextAreaRef.current.scrollHeight + "px";
    }
  }, [notes]);

  if (!user) return <p className="text-center mt-10">...</p>;

  const handleActivityChange = (selectedIds: string[]) => {
    setSelectedActivities(selectedIds);
  };

  const addCustomActivity = () => {
    if (
      customActivity.trim() &&
      !selectedActivities.includes(customActivity.trim())
    ) {
      setSelectedActivities([...selectedActivities, customActivity.trim()]);
      setCustomActivity("");
    }
  };

  const handleNotesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNotes(e.target.value);
    if (notesTextAreaRef.current) {
      notesTextAreaRef.current.style.height = "auto";
      notesTextAreaRef.current.style.height =
        notesTextAreaRef.current.scrollHeight + "px";
    }
  };

  const handleSubmit = async () => {
    if (!user) {
      alert("You must be logged in to save data.");
      return;
    }
    try {
      const userFitnessDataCollection = collection(
        db,
        "users",
        user.uid,
        "fitnessData"
      );

      const weightValue = weight.trim() === "" ? null : Number(weight);
      const stepsValue = steps.trim() === "" ? null : Number(steps);
      const caloriesValue = calories.trim() === "" ? null : Number(calories);
      const proteinValue = protein.trim() === "" ? null : Number(protein);

      await addDoc(userFitnessDataCollection, {
        userId: user.uid,
        activities: selectedActivities,
        weight: weightValue,
        steps: stepsValue,
        calories: caloriesValue,
        protein: proteinValue,
        mood,
        sleepQuality,
        notes,
        supplements,
        createdAt: serverTimestamp(),
      });
      alert("Diary saved!");
      setWeight("");
      setSteps("");
      setCalories("");
      setProtein("");
      setNotes("");
      setSelectedActivities([]);
      router.push("/"); // Redirect to the home page after successful save
    } catch (e) {
      alert("Save error: " + e);
    }
  };

  const activityOptions = initialActivities.map((activity) => ({
    id: activity.toLowerCase().replace(/\s+/g, "-"),
    name: activity,
    description: `Log your ${activity} activity for today.`,
  }));

  return (
    <div className="relative min-h-screen max-w-3xl mx-auto p-6  pb-16 flex flex-col">
      <MyHeader /> <br></br>
      <br></br>
      <br></br>
      <h1 className="text-2xl font-bold mb-4">Fitness Diary</h1>
      <div className="mb-5">
        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
          Today's activity:
        </label>
        <ActivitySelector
          activities={activityOptions}
          onChange={handleActivityChange}
        />
        <div className="flex space-x-2 mt-2">
          {/* ... (custom activity input) */}
        </div>
      </div>
      {/* Replace the individual input divs with the FitnessInputs component */}
      <FitnessInputs
        weight={weight}
        steps={steps}
        calories={calories}
        protein={protein}
        onWeightChange={setWeight}
        onStepsChange={setSteps}
        onCaloriesChange={setCalories}
        onProteinChange={setProtein}
      />
      <div className="mb-5 mt-2">
        <div className="relative">
          <textarea
            ref={notesTextAreaRef}
            id="notes"
            className="block py-2.5 px-0 flex-grow w-full text-sm text-gray-900 dark:text-white bg-transparent border-0 border-b-2 border-gray-200 appearance-none dark:text-gray-400 dark:border-gray-700 focus:outline-none focus:ring-0 focus:border-gray-200 peer resize-none"
            placeholder=" "
            value={notes}
            onChange={handleNotesChange}
            style={{ overflowY: "hidden" }}
          />
          <label
            htmlFor="notes"
            className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6  top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-white peer-focus:dark:text-white peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0  peer-focus:-translate-y-6"
          >
            Your notes
          </label>
        </div>
      </div>
      <button
        onClick={handleSubmit}
        className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
      >
        Save
      </button>
    </div>
  );
}
