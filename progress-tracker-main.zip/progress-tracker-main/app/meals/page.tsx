"use client";

import Link from "next/link";
import { useEffect, useState } from "react"; // Import useState and useEffect
import { auth, User } from "@/lib/firebase";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { useRouter } from "next/navigation";
import { GridMenu } from "../../components/GridMenu";
import MyHeader from "../../components/MyHeader";
import UserOverviewCard from "../../components/UserOverviewCard";

export default function HomePage() {
  const [user, setUser] = useState<User | null>(null);
  const router = useRouter();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (!u) router.push("/auth/login");
    });
    return () => unsubscribe();
  }, [router]);

  if (!user) {
    return <p className="text-center mt-10">Loading...</p>;
  }

  const handleLogout = async () => {
    await signOut(auth);
    router.push("/auth/login");
  };

  return (
    <div className="relative min-h-screen max-w-3xl mx-auto p-4 pt-16 pb-16 flex flex-col">
      <div>
        <MyHeader></MyHeader>
      </div>
      <div className="mt-8" />
      <h1 className="text-3xl font-bold mb-6">
        Hello,<br></br> {user.email}
      </h1>
      <div className="w-full">
        <UserOverviewCard className="w-full" />
      </div>
      <div className="mt-8 w-full">
        <GridMenu className="w-full" /> {/* Dodaj klasę w-full tutaj */}
      </div>
      <button
        onClick={handleLogout}
        className="absolute bottom-4 right-4 text-white py-2 px-4 rounded"
      >
        Log Out
      </button>
    </div>
  );
}
