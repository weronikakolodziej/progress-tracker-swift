// server.js
const { createServer } = require('http');
const { parse } = require('url');
const next = require('next');

const dev = process.env.NODE_ENV !== 'production';
const hostname = 'localhost'; // Możesz zmienić na '0.0.0.0' aby nasłuchiwać na wszystkich interfejsach
const port = process.env.PORT || 3000;
// when using middleware `hostname` and `port` must be provided below
const app = next({ dev, hostname, port, dir: './' }); // Ustaw dir na './'
const handle = app.getRequestHandler();

app.prepare().then(() => {
  createServer(async (req, res) => {
    try {
      // be sure to pass the hostname and port!
      // - tells next.js where to render the page
      await handle(req, res, parse(req.url, true));
    } catch (err) {
      console.error('Error occurred handling', req.url, err);
      res.statusCode = 500;
      res.end('internal server error');
    }
  })
    .once('error', (err) => {
      console.error('server error', err);
      process.exit(1);
    })
    .listen(port, hostname, () => {
      console.log(`> Server listening at http://${hostname}:${port}`);
    });
});